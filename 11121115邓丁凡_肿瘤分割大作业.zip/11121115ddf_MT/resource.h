﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 My11121115ddfMT.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_My11121108MTTYPE            130
#define IDD_DLG_FILECFG                 310
#define IDD_DLG_SHOW                    314
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_PIC_TRA                     1001
#define IDC_EDIT3                       1002
#define IDC_BUTTON_FLAIR                1002
#define IDC_PIC_T1                      1003
#define IDC_BUTTON_T1                   1004
#define IDC_PIC_T1CE                    1005
#define IDC_BUTTON_T1CE                 1006
#define IDC_PIC_T2                      1007
#define IDC_BUTTON_T2                   1008
#define IDC_SLIDER_ALL                  1009
#define IDC_PIC_FLAIR2                  1010
#define IDC_PIC_FLAIR                   1010
#define IDC_PIC_COR                     1011
#define IDC_PIC_SAG                     1012
#define IDC_SLIDER_TRA                  1013
#define IDC_SLIDER_SAG                  1014
#define IDC_SLIDER_COR                  1015
#define IDC_STATIC1                     1016
#define IDC_BUTTON_TRA                  1017
#define IDC_STATIC2                     1018
#define IDC_BUTTON_SEG                  1019
#define IDC_TRA3                        1020
#define IDC_BUTTON_COR                  1020
#define IDC_STATIC3                     1021
#define IDC_BUTTON_SEGMENT              1022
#define IDC_BUTTON_FORMER               1023
#define IDC_BUTTON_NEXT                 1024
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_SAGITAL                      32776
#define ID_CORONAL                      32777
#define ID_TRAVERSAL                    32778
#define ID_SHOW                         32779
#define ID_README                       32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        316
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
